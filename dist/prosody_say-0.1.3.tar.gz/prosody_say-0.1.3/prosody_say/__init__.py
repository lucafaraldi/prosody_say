from .core import ProsodySynthesizer

__version__ = "0.1.0"